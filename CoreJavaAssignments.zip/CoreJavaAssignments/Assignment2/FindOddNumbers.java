package com.broadridge.assignment2;

public class FindOddNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         int n = 187;
        
        //print all odd numbers
        int i=79;
        while (i<=n) {        	
        }
            if(i%2==1) {
                System.out.println("  "+ i);
            }
            i++;

	}

}
