package com.broadridge.assignment4;

import java.util.TreeSet;

public class TreeSetProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 TreeSet tSet = new TreeSet();
		   
		    //add elements to TreeSet
		    tSet.add("43");
		    tSet.add("46");
		    tSet.add("26");
		    tSet.add("85");
		    tSet.add("25");
		    System.out.println("Lowest value Stored in Java TreeSet is : " + tSet.first());
	  	    System.out.println("Highest value Stored in Java TreeSet is : " + tSet.last());
		 
		  }

	}


